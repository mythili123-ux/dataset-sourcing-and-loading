import React from "react";
import LoginForm from "../components/LoginForm";
import Chatbot from "../components/Chatbot";

const WelcomePage: React.FC = () => {
  return (
    <div style={{ width: "100%", maxWidth: "500px", margin: "0 auto", paddingTop: "5rem" }}>
      <LoginForm />
      <Chatbot />
    </div>
  );
};

export default WelcomePage;
