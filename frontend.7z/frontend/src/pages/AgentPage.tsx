import React from "react";
import Chatbot from "../components/Chatbot";

const AgentPage: React.FC = () => {
  return (
    <div className="card" style={{ maxWidth: "600px", margin: "2rem auto" }}>
      <h1>Agent Page</h1>
      <p>Welcome, agent!</p>
      <Chatbot />
    </div>
  );
};

export default AgentPage;
