import React from "react";
import Chatbot from "../components/Chatbot";

const UserPage: React.FC = () => {
  return (
    <div className="card" style={{ maxWidth: "600px", margin: "2rem auto" }}>
      <h1>User Page</h1>
      <p>Welcome, user!</p>
      <Chatbot />
    </div>
  );
};

export default UserPage;
