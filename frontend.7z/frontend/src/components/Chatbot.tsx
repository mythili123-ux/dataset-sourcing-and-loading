import React, { useState } from "react";

const Chatbot: React.FC = () => {
  const [open, setOpen] = useState(false);

  return (
    <>
      <div
        id="chat-btn"
        onClick={() => setOpen(!open)}
      >
        Click here for AI HELP
      </div>
      {open && (
        <div id="chat-box">
          <h4>Need help?</h4>
          <p>Ask me anything!</p>
        </div>
      )}
    </>
  );
};

export default Chatbot;
