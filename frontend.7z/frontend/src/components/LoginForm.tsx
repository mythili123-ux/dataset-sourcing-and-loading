import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const LoginForm: React.FC = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [signup, setSignup] = useState(false);
  const navigate = useNavigate();

  const sendRequest = async () => {
    const endpoint = signup ? "/signup" : "/login";
    try {
      const res = await axios.post(`http://127.0.0.1:5000${endpoint}`, {
        email,
        password,
      });
      if (!res.data.success) {
        alert(res.data.error);
        return;
      }
      if (res.data.role === "agent") navigate("/agent");
      else navigate("/user");
    } catch (err: any) {
      if (err.response && err.response.data && err.response.data.error) {
        alert(err.response.data.error);
      } else {
        console.error(err);
        alert("Something went wrong");
      }
    }
  };

  return (
    <div className="card" style={{ maxWidth: "400px", margin: "0 auto" }}>
      <h2>{signup ? "Sign Up" : "Login"}</h2>
      <input
        type="email"
        placeholder="Email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
      />
      <input
        type="password"
        placeholder="Password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
      />
      <div style={{ display: "flex", justifyContent: "space-between" }}>
        <button className="primary" onClick={() => { setSignup(false); sendRequest(); }}>
          Login
        </button>
        <button className="secondary" onClick={() => { setSignup(true); sendRequest(); }}>
          Sign Up
        </button>
      </div>
    </div>
  );
};

export default LoginForm;
