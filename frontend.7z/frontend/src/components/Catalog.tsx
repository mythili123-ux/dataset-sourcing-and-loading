import React from "react";

type Product = [number, string, number];

interface Props {
  products: Product[];
}

const Catalog: React.FC<Props> = ({ products }) => {
  return (
    <ul style={{
      display: "flex",
      gap: "1rem",
      overflowX: "auto",
      padding: "1rem 0",
    }}>
      {products.map(([id, name, price]) => (
        <li
          key={id}
          className="card"
          style={{
            minWidth: "200px", 
            flex: "0 0 auto", // keep column width fixed
            textAlign: "center"
          }}
        >
          <h3>{name}</h3>
          <p>Price: <strong>${price}</strong></p>
          <button className="primary">Buy Now</button>
        </li>
      ))}
    </ul>
  );
};

export default Catalog;
